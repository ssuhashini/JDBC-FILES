
dig0 = int(input("Enter digit 0 (Either 0 or 1)\n"))
dig1 = int(input("Enter digit 1 (Either 0 or 1)\n"))
dig2 = int(input("Enter digit 2 (Either 0 or 1)\n"))
dig3 = int(input("Enter digit 3 (Either 0 or 1)\n"))

decimal = (dig0 * (2 ** 0)) + (dig1 * ( 2 ** 1)) + (dig2 * (2 ** 2)) + (dig3 * (2 ** 3))
print("The decimal number is ", decimal )
