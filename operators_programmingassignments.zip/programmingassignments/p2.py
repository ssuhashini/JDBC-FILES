
n = int(input('Enter power\n'))
res = 2 ** n
print('2 raised to ', n , 'is', res ) 

