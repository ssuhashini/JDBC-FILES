
character = input("Enter a character\n");
print("The unicode encoding is ", ord(character))
