
base = int(input("Enter the base\n"))
power = int(input("Enter power\n"))
res = base ** power
print(base, ' raised to ', power , 'is', res ) 

