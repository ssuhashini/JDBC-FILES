
fahr = float(input("Enter farenheit value\n"))
celcius = (5/9)*(fahr - 32)

print("Celcius = ", celcius)
