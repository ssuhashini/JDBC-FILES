
num1 = float(input("Enter the first float number\n"))
num2 = float(input("Enter the second float number\n"))
print(format(num1/num2, '.6e'))
