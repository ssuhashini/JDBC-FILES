
import math
#from math import factorial

num_cities = int(input("Enter number of cities\n"))
routes = math.factorial(num_cities)
print("The possible routes for ", num_cities, "is ", routes)
