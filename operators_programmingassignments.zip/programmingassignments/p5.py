
print(ord('H'), ord('e'), ord('l'), ord('l'), ord('o'), ord(' '), ord('W'), ord('o'), ord('r'), ord('l'), ord('d'))
